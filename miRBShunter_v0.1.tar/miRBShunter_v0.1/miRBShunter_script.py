import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
import re

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
def ReverseComplement1(seq):
    seq_dict = {'A':'T', 'A':'U','T':'A','U':'A','G':'C','C':'G'}
    return "".join([seq_dict[base] for base in reversed(seq)])
  
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: python ./miRBShunter_make_script.py [options] [peaksbedfile] [mirnafastafile]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output files. Default is current directory.")
    parser.add_option("-t", "--tempdir", action="store", dest="tempdir", default=".", type="string", help="directory for temporary files. Default is current directory.")
    parser.add_option("-p", "--pvalue", action="store", dest="pvalue", default="0.001", type="float", help="pvalue threshold for peaks. Default is 0.001.")
    parser.add_option("-r", "--reads", action="store", dest="reads", default="5", type="int", help="number of reads threshold for peaks. Default is 5.")
    parser.add_option("-d", "--genomefastadir", action="store", dest="genomefastadir", default=".", type="string", help="directory of fasta files for reference genome. Default is current directory.")
    parser.add_option("-g", "--genome", action="store", dest="genome", default="mm10", type="string", help="mm10/hg19 Default is mm10.")
    parser.add_option("-f", "--prefix", action="store", dest="prefix", default="test", type="string", help="prefix name for output files. Default is test.")
    parser.add_option("-b", "--fastaBG", action="store", dest="fastaBG", default="", type="string", help="bg fasta file for motif enrichment. Default is sequences scrumble.")
    

    (options, args) = parser.parse_args()
    if len(args) != 2:
        parser.error("bed file of peaks, mirna seq fasta are required")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)
    
    if not os.path.isdir(options.tempdir):
        parser.error("Not a valid directory: '%s'." % options.tempdir)
	
    #if not os.path.isdir(options.genomefastadir):
     #   parser.error("Not a valid directory: '%s'." % options.genomefastadir)

    options.entity1 = args[0]
    options.entity2 = args[1]
    #options.entity3 = args[2]
    
    return options
    
    
    
def table(options):
    file_bed = file(options.entity1, 'r')
    file_mirna = file(options.entity2, 'r')
    #file_fasta_bg = file(options.entity3, 'r')
    #file_out = file("miRBShunter_script.sh", 'w')
    
    os.system("python ./miRBShunter_scripts/filter_bed.py %s -p %s -r %s -o %s -f %s\n " %(options.entity1, options.pvalue, options.reads, options.tempdir, options.prefix))
    print("peaks bed file filtered")
    #file_fasta_name = os.path.join(options.tempdir,'%s_mfe_per_cluster.txt' %(file_out_base1))
    
    os.system("homerTools extract %s%s_pval%s_reads%s_peakname.bed %s -fa > %s%s_pval%s_reads%s_peakname.fa\n " %( options.tempdir, options.prefix, options.pvalue, options.reads, options.genomefastadir,  options.tempdir, options.prefix, options.pvalue, options.reads))
    
    os.system("annotatePeaks.pl  %s %s -annStats %s%s_pval%s_reads%s_peakname.annstat > %s%s_pval%s_reads%s_peakname.anno\n " %(options.entity1, options.genome, options.outdir, options.prefix, options.pvalue, options.reads,  options.outdir, options.prefix, options.pvalue, options.reads))

    print("peaks sequences extracted and annotated on %s genome" %(options.genome))

    os.system("python ./miRBShunter_scripts/prepare_sh_motif.py %s -o %s\n " %(options.entity2, options.tempdir))
    
    os.system("sh %smotif_script.sh\n" %(options.tempdir))
    print("miRNA sequences parsed\nstarting de novo motif finding with Homer")

    if options.fastaBG=="":
	os.system("findMotifs.pl %s%s_pval%s_reads%s_peakname.fa fasta '%shomer_output' -mcheck '%smotif_all' -norevopp -noknown -len 7 -bits\n " %(options.tempdir, options.prefix, options.pvalue, options.reads,  options.tempdir, options.tempdir))
    else:
	os.system("findMotifs.pl %s%s_pval%s_reads%s_peakname.fa fasta '%shomer_output' -fastaBg %s -mcheck '%smotif_all' -norevopp -noknown -len 7 -bits\n " %(options.tempdir, options.prefix, options.pvalue, options.reads,  options.tempdir, options.fastaBG, options.tempdir))
    
    #os.system("cd %s/homer_output/homerResults/\n" %(options.tempdir))
    
    motif_dir=options.tempdir+"homer_output/homerResults/"
    
    print("Calculating combined score and motifs filtering")
    for filename in os.listdir(motif_dir):
	#print filename
	#filename_path="./"+motif_dir+filename
	filename_path=motif_dir+filename
	if filename.endswith("html"):
	    #print filename
	    #print ("python ./miRBShunter_scripts/parsing_html_homer.py %s -o %s\n" %( filename_path, options.tempdir))
	    os.system("python ./miRBShunter_scripts/parsing_html_homer.py %s -o %s\n" %( filename_path, options.tempdir))
	
    os.system("cat %smotif*info_parsed.txt > %sall_motif_parsed.txt\n" %(options.tempdir, options.tempdir))
    
    os.system("cat %smotif*info_motif_list.txt > %sall_motif_list_CS1.txt\n" %(options.tempdir, options.tempdir))
    
    meme_dir=options.tempdir+"meme_motif/"
    meme_dir_output=options.outdir+"meme_motif/"
    os.mkdir(meme_dir)
    os.mkdir(meme_dir_output)
    #print ("python ./miRBShunter_scripts/convert_motif_homer_to_meme.py %sall_motif_list_CS1.txt -o %s\n" %( options.tempdir, meme_dir))
    
    os.system("python ./miRBShunter_scripts/convert_motif_homer_to_meme.py %sall_motif_list_CS1.txt -o %s\n" %( options.tempdir, meme_dir))
    os.system("cp %s* %s" %(meme_dir, meme_dir_output ))
    print("motifs found and stored in output folder: %s\nSearch for motifs in peaks sequences with FIMO of MEME suite" %(meme_dir_output))

    count=0
    for filename in os.listdir(meme_dir):
	#file_meme = file(filename, 'r')
	count=count+1
	#print ("fimo --thresh 0.0002 -norc -o %sfimo_output_motif%s %s%s %s%s_pval%s_reads%s_peakname.fa\n" %(options.tempdir, count,  meme_dir, filename, options.tempdir, options.prefix, options.pvalue, options.reads))
	os.system("fimo --thresh 0.0002 -norc -o %sfimo_output_motif%s %s%s %s%s_pval%s_reads%s_peakname.fa\n" %(options.tempdir, count, meme_dir, filename, options.tempdir, options.prefix, options.pvalue, options.reads))
    
    os.system("cat %sfimo_output_motif*/fimo.txt > %sall_motif_fimo_output.txt\n" %( options.tempdir, options.tempdir))
    
    print("Extracting sequences for duplex")
    os.system("python ./miRBShunter_scripts/prepare_table_for_duplex.py %sall_motif_fimo_output.txt %s%s_pval%s_reads%s_peakname.bed %sall_motif_parsed.txt -o %s\n" %( options.tempdir, options.tempdir, options.prefix, options.pvalue, options.reads, options.tempdir, options.tempdir))
    
    os.system("mkdir %soutput_duplex\n" %(options.tempdir))
    
    os.system("mkdir %ssequences_for_duplex\n" %(options.tempdir))
    
    seq_dir=options.tempdir+"sequences_for_duplex/"
    duplex_dir=options.tempdir+"output_duplex/"
    
    os.system("python ./miRBShunter_scripts/prepare_seq_rnaduplex_validation_mod_for_pipeline.py %s%s_pval%s_reads%s_peakname.fa %s %stable_for_duplex.txt -o %s \n" %(options.tempdir,  options.prefix, options.pvalue, options.reads, options.entity2, options.tempdir, seq_dir))
    
    os.system("cat %s*bed > %sall_bed.txt\n" %(seq_dir, seq_dir))
    
    os.system("rm %s*bed\n" %(seq_dir))
    
    print("miRNA-mRNA heteroduplex structures calculation with RNAduplex of Vienna Package")
    for filename in os.listdir(seq_dir):
	#file_seq = file(filename, 'r')
	os.system("RNAduplex -noLP < %s%s > %s%s_output\n" %(seq_dir, filename, duplex_dir, os.path.splitext(os.path.basename(filename))[0]))
   
    os.system("rm %sall_bed_output\n" %(duplex_dir))
    
    for filename in os.listdir(duplex_dir):
	#file_duplex = file(filename, 'r')
	#print ("python ./miRBShunter_scripts/parsing_rnaduplex_output_validation_mod_for_pipeline.py  %stable_for_duplex.txt %s%s %s -o %s\n" %(options.tempdir, duplex_dir, filename, options.entity2, duplex_dir))
	os.system("python ./miRBShunter_scripts/parsing_rnaduplex_output_validation_mod_for_pipeline.py  %stable_for_duplex.txt %s%s %s -o %s\n" %(options.tempdir, duplex_dir, filename, options.entity2, duplex_dir))
    
    os.system("cat %s*energy.txt > %senergy_all.txt\n" %(duplex_dir, options.tempdir))
    
    os.system("cat %s*cluster.txt > %sstructure_mirna_all.txt\n" %(duplex_dir, options.tempdir))
    
    os.system("cat %s*target.txt > %sstructure_target_all.txt\n" %(duplex_dir, options.tempdir))
    
    print("Calculating duplex score")
    os.system("python ./miRBShunter_scripts/calculate_vs_score_expected_pattern_control.py %senergy_all.txt %stable_for_duplex.txt %s -o %s \n" %(options.tempdir, options.tempdir, options.entity2, options.outdir))
    

    
    

    file_bed.close()

    
    print ("\nScript done :)\ncheck results in %s\n" %(options.outdir) )
       


if __name__=='__main__':
    main()        
    
        
        
        
