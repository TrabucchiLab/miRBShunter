import os
import sys
import re
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
    
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    #parser.add_option("-w", "--window", action="store", dest="window", default="60", type="int", help="window length to add. Default is 60.")
    

    (options, args) = parser.parse_args()
    if len(args) != 3:
        parser.error("table output homer,  rnaduplex output and mirna file is required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    options.entity2 = args[1]
    options.entity3 = args[2]
    
    return options
    
    
    
def table(options):
    #file_in_name1 = os.path.join(options.outdir, options.entity1)
    #file_in_name2 = os.path.join(options.outdir, options.entity2)
   
    file_out_base1 = os.path.splitext(os.path.basename(options.entity2))[0]
    file_out_name = os.path.join(options.outdir,'%s_mfe_per_cluster.txt' %(file_out_base1))
    file_out_name2 = os.path.join(options.outdir,'%s_mfe_per_cluster_target.txt' %(file_out_base1))
    file_out_name1 = os.path.join(options.outdir,'%s_energy.txt' %(file_out_base1))
    
    peak="peak_"+file_out_base1.split("_")[1]
    mirna=file_out_base1.split("_")[2]
    motif=file_out_base1.split("_")[3]
    position=file_out_base1.split("_")[4]
    
    #print peak, mirna, motif, position
    
    file_in = file(options.entity2, 'r')
    file_mirna = file(options.entity3, 'r')
    
    file_out=file(file_out_name, 'w')
    file_out1=file(file_out_name1, 'w')
    file_out_t=file(file_out_name2, 'w')
    
    #file_out.write("name\tpos1\tpos2\tpos3\tpos4\tpos5\tpos6\tpos7\tpos8\tpos9\tpos10\tpos11\tpos12\tpos13\tpos14\tpos15\tpos16\tpos17\tpos18\tpos19\tpos20\tpos21\tpos22\n")
    #file_out1.write("name\tpos1\tpos2\tpos3\tpos4\tpos5\tpos6\tpos7\tpos8\tpos9\tpos10\tpos11\tpos12\tpos13\tpos14\tpos15\tpos16\tpos17\tpos18\tpos19\tpos20\tpos21\tpos22\n")
    
    file_tab=file(options.entity1, 'r')
    
    mirna_array=[]
    mirna_len_array=[]
    #mirna_len_tab=[]
    for line in file_mirna:
        if line.startswith(">"):
            mirna_array.append(line.split(">")[1].split("\n")[0])
        else:
            mirna_len_array.append(len(line.split("\n")[0]))
        #mirna_len_tab.append(line.split("\t")[2].split("\n")[0])
    #print len(mirna_len_array)
    
    for line in file_tab:
        if not line.startswith("gene ID"):
            motif_name_homer="motif"+(line.split("\t")[0])
            peak_name_homer=(line.split("\t")[1])
            mirna_name_homer=(line.split("\t")[13])
            position_name_homer=(line.split("\t")[9])
            
            if motif_name_homer==motif and peak_name_homer==peak and mirna_name_homer==mirna and position_name_homer==position:
                #print peak_name_homer, mirna_name_homer, motif_name_homer, position_name_homer
                #p_i=(int(line.split("\t")[3]))
                #p_f=(int(line.split("\t")[4]))
                m_i=(float(line.split("\t")[15]))
                m_f=(float(line.split("\t")[16]))
                m_i=int(m_i)
                m_f=int(m_f)

    #print m_i, m_f
    ##print (mirna_name_homer)
    
    
    
    #mirna_array=("mir103", "mir30a", "mir26a", "mir181b", "mir16", "mir302b", "mir99a", "mir6240", "mir183", "mir182a", "mir181a")
    #mirna_len_array=(22, 22, 22, 23, 20, 22, 22, 26, 22, 25, 23)
    A=0
    B=0
    i=0
    j=0
    for line in file_in:
        if line.startswith(">peak"):
            name=(line.split(">")[1].split("\n")[0])
            file_out.write("%s\t" %(file_out_base1))
            file_out1.write("%s\t" %(file_out_base1))
            file_out_t.write("%s\t" %(file_out_base1))
            A=0
            B=0
            i=0
            j=0
            dx1=0 
            dx2=0 
            dx3=0 
            dx4=0 
            dx5=0 
            sx1=0 
            sx2=0 
            sx3=0 
            sx4=0
            dxt1=0 
            dxt2=0 
            dxt3=0 
            dxt4=0 
            dxt5=0 
            sxt1=0 
            sxt2=0 
            sxt3=0 
            sxt4=0
            count_p_target=0
            count_p_mirna=0
            count_p_mirna_seed=0
            count_p_mirna_seed_target=0
            count_p_mirna_motif_target=0
            count_p_mirna_motif=0
        if line.startswith(">mir"):
            mirna_name=(line.split(">")[1].split("\n")[0])
            for j in range(len(mirna_array)):
                if mirna_array[j]==mirna_name:
                    #print "entro"
                    mirna_len=mirna_len_array[j]
            #print mirna_name, mirna_len
        if (line.startswith("(") or line.startswith(".")) and A==0: # or line.startswith("{") or line.startswith(",")):
            #print "entro1"
            seq_mirna=line.split("&")[0]
            seq_target=line.split("&")[1].split("   ")[0]
            target_seq_rev=seq_target[::-1]
            energy=line.split("  (")[1].split(")\n")[0]
            file_out1.write("%s\t" %(energy))
            A=1
            new_seq=""
            new_seq_t=""
            
            #count number of paired nt in mirna
            for pos in seq_mirna:
                if pos=="(":
                    count_p_mirna=count_p_mirna+1
            #count number of paired nt in target
            for pos in seq_target:
                if pos==")":
                    count_p_target=count_p_target+1
            
            
            st_target=int(line.split("  :")[1].split(",")[0])
            end_target=int(line.split(",")[1].split(" ")[0])
            
            #st_mirna=int(line.split("   ")[1].split(",")[0])
            st_mirna=int(line.split("  ")[1].split(",")[0])
            end_mirna=int(line.split("  :")[0].split(",")[1])
            
            
            """
            k=0
            if st_mirna<8:
                for pos in seq_mirna[st_mirna:8]:
                    k=k+1
                    if pos=="(" and target_seq_rev[k]==")":
                        count_p_mirna_seed_target=count_p_mirna_seed_target+1
            else:
                count_p_mirna_seed_target=0
               
            #print count_p_mirna_seed_target
            """
            #count number of paired nt in seed in target
            if st_mirna<8:
                new_end=9-st_mirna
                for pos in target_seq_rev[1:new_end]:
                    if pos==")":
                        count_p_mirna_seed_target=count_p_mirna_seed_target+1
            
            #count number of paired nt in motif in target
            
            for pos in target_seq_rev[m_i-1:m_f]:
                    if pos==")":
                        count_p_mirna_motif_target=count_p_mirna_motif_target+1
            
            
            #extend duplex structure to mirna seq len
            if len(seq_mirna)<mirna_len:
                seq_add=''
                st=int(line.split("  ")[1].split(",")[0])
                end=int(line.split("  :")[0].split(",")[1])
                #print st, end
                for i in range(1,st):
                    seq_add=seq_add+"."
                seq_add=seq_add+seq_mirna
                for j in range(len(seq_add), mirna_len):
                    seq_add=seq_add+"."
                #print seq_add, len(seq_add)
                seq_mirna=seq_add
            
            #count number of nt paired in seed in mirna
            for pos in seq_mirna[1:8]:
                if pos=="(":
                    count_p_mirna_seed=count_p_mirna_seed+1
            
            #count number of nt paired in motif in mirna
            for pos in seq_mirna[m_i-1:m_f]:
                if pos=="(":
                    count_p_mirna_motif=count_p_mirna_motif+1
            
            #extend duplex structure to target seq len
            if len(seq_target)<mirna_len:
                seq_add=''
                st=int(line.split("  :")[1].split(",")[0])
                end=int(line.split(",")[1].split(" ")[0])
                #print st, end
                for i in range(1,st):
                    seq_add=seq_add+"."
                seq_add=seq_add+seq_target
                for j in range(len(seq_add), mirna_len):
                    seq_add=seq_add+"."
                #print seq_add, len(seq_add)
                seq_target=seq_add
            
            target_seq_rev=seq_target[::-1]
            
            #write duplex structure mirna
            for pos in seq_mirna:
                    if pos==".":
                        new_seq=new_seq+"0"
                        file_out.write("%s\t" %(0))
                    if pos=="(":
                        new_seq=new_seq+"1"
                        file_out.write("%s\t" %(1))
             
            #write duplex structure target            
            for pos in target_seq_rev:
                    if pos==".":
                        new_seq_t=new_seq_t+"0"
                        file_out_t.write("%s\t" %(0))
                    if pos==")":
                        new_seq_t=new_seq_t+"1"
                        file_out_t.write("%s\t" %(1))
                        
            file_out1.write("%s\t%s\t%s\t%s\t%s\t%s\t" %(count_p_mirna, mirna_len-count_p_mirna, count_p_mirna_motif, count_p_mirna_motif_target, count_p_mirna_seed, count_p_mirna_seed_target))
            
            """

            if seq_mirna[1:5]=="(((.":
                #print "(((."
                dx1=1
                file_out1.write("3\t")
            if seq_mirna[1:6]=="((((.":
                #print "((((."
                dx2=1
                file_out1.write("4\t")
            if seq_mirna[1:7]=="(((((.":
                #print "(((((."
                dx3=1
                file_out1.write("5\t")
            if seq_mirna[1:8]=="((((((.":
                #print "((((((."
                dx4=1
                file_out1.write("6\t")
            if seq_mirna[1:8]=="(((((((":
                #print "((((((("
                dx5=1
                file_out1.write("7\t")
   
            if seq_mirna[4:8]==".(((" and dx1==0:
                #print "(((."
                sx1=1
                file_out1.write("3\t")
            if seq_mirna[3:8]==".((((":
                #print "((((."
                sx2=1
                file_out1.write("4\t")
            if seq_mirna[2:8]==".(((((":
                #print "(((((."
                sx3=1
                file_out1.write("5\t")
            if seq_mirna[1:8]==".((((((":
                #print "((((((."
                sx4=1
                file_out1.write("6\t")
            
            if dx1==0 and dx2==0 and dx3==0 and dx4==0 and dx5==0 and sx1==0 and sx2==0 and sx3==0 and sx4==0:
                file_out1.write("0\t")
            
            
            
            if target_seq_rev[1:5]=="))).":
                #print "(((."
                dxt1=1
                file_out1.write("3\t")
            if target_seq_rev[1:6]==")))).":
                #print "((((."
                dxt2=1
                file_out1.write("4\t")
            if target_seq_rev[1:7]=="))))).":
                #print "(((((."
                dxt3=1
                file_out1.write("5\t")
            if target_seq_rev[1:8]==")))))).":
                #print "((((((."
                dxt4=1
                file_out1.write("6\t")
            if target_seq_rev[1:8]==")))))))":
                #print "((((((("
                dxt5=1
                file_out1.write("7\t")
            
            if target_seq_rev[4:8]==".)))" and dxt1==0:
                #print "(((."
                sxt1=1
                file_out1.write("3\t")
            if target_seq_rev[3:8]==".))))":
                #print "((((."
                sxt2=1
                file_out1.write("4\t")
            if target_seq_rev[2:8]==".)))))":
                #print "(((((."
                sxt3=1
                file_out1.write("5\t")
            if target_seq_rev[1:8]==".))))))":
                #print "((((((."
                sxt4=1
                file_out1.write("6\t")
            
            if dxt1==0 and dxt2==0 and dxt3==0 and dxt4==0 and dxt5==0 and sxt1==0 and sxt2==0 and sxt3==0 and sxt4==0:
                file_out1.write("0\t")
            """
            
    file_out.write("\n")
    file_out1.write("\n")
    file_out_t.write("\n")
    
    file_in.close()
    #file_out.close()
    

    ##print ("results stored into file '%s'. "% os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()
