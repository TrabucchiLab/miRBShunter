import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
import re

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
def ReverseComplement1(seq):
    seq_dict = {'A':'T', 'A':'U','T':'A','U':'A','G':'C','C':'G'}
    return "".join([seq_dict[base] for base in reversed(seq)])
  
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    

    (options, args) = parser.parse_args()
    if len(args) != 0:
        parser.error("no arguments required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    #options.entity1 = args[0]
    #options.entity2 = args[1]
   
    
    return options
    
    
    
def table(options):
    file_out = file("rnaduplex_script.sh", 'w')
    for filename in os.listdir(os.getcwd()):
    	file_in = file(filename, 'r')
        file_out_base1 = os.path.splitext(os.path.basename(filename))[0]
	#print file_out_base1
        file_out.write("mkdir ../output_duplex/%s\n" %(file_out_base1))
        file_out.write("cd ../output_duplex/%s\n" %(file_out_base1))
        file_out.write("RNAduplex -noLP < ../../sequences_for_duplex/%s.fa > %s_output\n" %(file_out_base1, file_out_base1))
	file_out.write("cd ../../sequences_for_duplex/\n")
        

    file_in.close()
    file_out.close()
    
    #print ("script created :)" )
       


if __name__=='__main__':
    main()        
    
        
        
        
