import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
from Bio.Seq import Seq

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
    
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    #parser.add_option("-p", "--pvalue", action="store", dest="pvalue", default="0.001", type="float", help="set pvalue threshold. Default 0.001.")
    #parser.add_option("-r", "--reads", action="store", dest="reads", default="10.0", type="float", help="set the minimal number of reads. Default is 10.0.")
    

    (options, args) = parser.parse_args()
    if len(args) != 1:
        parser.error("list of motif to convert is required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    
   
    
    return options
    
    
    
def table(options):
    file_in_name1 = options.entity1
    file_in= file(file_in_name1, 'r')
    
    for line in file_in:
        in_dir=options.outdir.split("meme_motif/")[0]+"/homer_output/homerResults/"
        file_name=os.path.join(in_dir,'%s.motif' % (  line.split("\n")[0]))     #"./homer_output/homerResults/"+line.split("\n")[0]+".motif"
        file_motif=file(file_name, 'r')
        file_out_base=line.split("\n")[0]+".meme"
        file_out_name = os.path.join(options.outdir,'%s' % ( file_out_base))
        file_out=file(file_out_name, 'w')
        file_out.write("MEME version 4.4\n\n")
        file_out.write("ALPHABET= ACGT\n\n")
        file_out.write("strands: + -\n\n")
        file_out.write("Background letter frequencies (from uniform background):\nA 0.25000 C 0.25000 G 0.25000 T 0.25000\n\n")
        file_out.write("MOTIF%s\n\nletter-probability matrix: alength= 4 w= 7 nsites= 20 E= 0\n" %(line.split("motif")[1].split("\n")[0]))
        for line in file_motif:
            if not line.startswith(">"):
                file_out.write("%s" %(line))
        

    
    file_in.close()
    file_out.close()
    

    #print ("results stored into file '%s'. " % os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()        
    
