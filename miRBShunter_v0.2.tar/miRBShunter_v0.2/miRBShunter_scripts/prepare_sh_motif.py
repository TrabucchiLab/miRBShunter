import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
from Bio.Seq import Seq
import re

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
def ReverseComplement1(seq):
    seq_dict = {'A':'T', 'A':'U','T':'A','U':'A','G':'C','C':'G'}
    return "".join([seq_dict[base] for base in reversed(seq)])
  
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    

    (options, args) = parser.parse_args()
    if len(args) != 1:
        parser.error("fasta file is required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    #options.entity2 = args[1]
   
    
    return options
    
    
    
def table(options):
    
    file_in = file(options.entity1, 'r')

    file_name=os.path.join(options.outdir,'mirna_reverse_complement.txt' ) 
    file_name_sh=os.path.join(options.outdir,'motif_script.sh') 
    file_out_RC = file(file_name, 'w')
    file_out_sh = file(file_name_sh, 'w')
    for line in file_in:
        if line.startswith(">"):
            name=line.split(">")[1].split("\n")[0]
        else:
            seq=Seq(line.split("\n")[0])
            RC=seq.reverse_complement()
            #file_out.write(">let7\nUGAGGUAGUAGGUUGUAUAGUU\n%s\n%s\n" %(name,seq))
            file_out_RC.write(">%s\n%s\n" %(name,RC))
            file_out_sh.write("seq2profile.pl %s 1 %s_RC > %s/%s_RC.motif\n" %(seq, name, options.outdir, name))
    
    file_out_sh.write("cd %s\n" %(options.outdir))     
    file_out_sh.write("cat *_RC.motif > motif_all")       
   

    
    
    
    
    
            
            
    file_in.close()
    
    
    #print ("Done!") 
       


if __name__=='__main__':
    main()        
    
