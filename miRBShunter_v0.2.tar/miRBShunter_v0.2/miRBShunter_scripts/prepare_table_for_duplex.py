import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
from Bio.Seq import Seq

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
    
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    #parser.add_option("-p", "--pvalue", action="store", dest="pvalue", default="0.001", type="float", help="set pvalue threshold. Default 0.001.")
    #parser.add_option("-r", "--reads", action="store", dest="reads", default="10.0", type="float", help="set the minimal number of reads. Default is 10.0.")
    

    (options, args) = parser.parse_args()
    if len(args) != 3:
        parser.error("fimo output for all motif,  bed file of peaks, all_motif_parsed with CS score are required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    options.entity2 = args[1]
    options.entity3 = args[2]

    return options
    
    
    
def table(options):
    file_in_name1 = options.entity1
    file_fimo= file(file_in_name1, 'r')
    file_bed= file(options.entity2, 'r')
    file_cs= file(options.entity3, 'r')
    
    #file_out_base1 = os.path.splitext(os.path.basename(options.entity1))[0]
    file_out_name = os.path.join(options.outdir,'table_for_duplex.txt' )
    file_out = file(file_out_name, 'w')
    
    peak_chr=[]
    peak_st=[]
    peak_end=[]
    peak_name=[]
    peak_strand=[]
    for line in file_bed:
        peak_chr.append(line.split("\t")[0])
        peak_st.append(int(line.split("\t")[1]))
        peak_end.append(int(line.split("\t")[2]))
        peak_name.append(line.split("\t")[3])
        peak_strand.append(line.split("\t")[5].split("\n")[0])
    #print len(peak_name)
    
    
    motif_id=[]
    line_file_cs=[]
    for line in file_cs:
        cs=float(line.split("\t")[8])
        if cs>=1:
            line_file_cs.append(line.split("\n")[0])
            motif_id.append(line.split("\t")[0])
    #print len(motif_id)     
        
    i=0
    j=0
    for line in file_fimo:
        if not line.startswith("#pattern"):
            peak_name_fimo=line.split("\t")[1]
            for j in range(len(peak_name)):
                if peak_name_fimo==peak_name[j]:
                    motif_st_fimo=int(line.split("\t")[2])
                    motif_end_fimo=int(line.split("\t")[3])
                    if peak_strand[j]=="+":
                        motif_st_fimo_genome=peak_st[j]+motif_st_fimo
                        motif_end_fimo_genome=motif_st_fimo_genome+7
                    if peak_strand[j]=="-":
                        motif_st_fimo_genome=peak_end[j]-motif_end_fimo
                        motif_end_fimo_genome=motif_st_fimo_genome+7
                    motif_chr_fimo_genome=peak_chr[j]
                    #pos_genome=peak_chr+":"+str(motif_st_fimo_genome)+"-"+str(motif_end_fimo_genome)
            motif_id_fimo="motif"+line.split("\t")[0]
            for i in range(len(motif_id)):
                if motif_id_fimo==motif_id[i]:
                    file_out.write("%s\t%s:%s-%s\t%s\n" %(line.split("\n")[0], motif_chr_fimo_genome, motif_st_fimo_genome, motif_end_fimo_genome, line_file_cs[i]))
                    
        

    
    file_fimo.close()
    file_out.close()
    

    #print ("results stored into file '%s'. "% os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()        
    
