import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
from Bio.Seq import Seq

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
    
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    #parser.add_option("-p", "--pvalue", action="store", dest="pvalue", default="0.001", type="float", help="set pvalue threshold. Default 0.001.")
    #parser.add_option("-r", "--reads", action="store", dest="reads", default="10.0", type="float", help="set the minimal number of reads. Default is 10.0.")
    

    (options, args) = parser.parse_args()
    if len(args) != 1:
        parser.error("file html output homer motif finding, one for each motif, is required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    
   
    
    return options
    
    
    
def table(options):
    file_in_name1 = options.entity1
    
   
    file_out_base1 = os.path.splitext(os.path.basename(options.entity1))[0]
   
    file_out_name = os.path.join(options.outdir,'%s_parsed.txt' % ( file_out_base1))
    file_list_out_name = os.path.join(options.outdir,'%s_motif_list.txt' % ( file_out_base1))
    
    
    
    
    file_in= file(file_in_name1, 'r')
   
    file_out = file(file_out_name, 'w')
    file_list_out = file(file_list_out_name, 'a')

    #parsing file .pk
    #list_array=[]
    i=0
    A=0
    orientation=''
    for line in file_in:
        if line.startswith("<TR><TD>p-value:"):
            pval=float(line.split("e-")[1].split("<")[0])
            #print pval
        if line.startswith("<TR><TD>Percentage of Target"):
            perc_seq=float(line.split(">")[4].split("%")[0])
            #print perc_seq
        if line.startswith("<H4>"):
            mirna_name=(line.split(">")[1].split("_")[0])
            #print mirna_name
        if line.startswith("<TR><TD>Score:"):
            score=float(line.split(">")[4].split("<")[0])
            #print score
        if line.startswith("<TR><TD>Offset:"):
            offset=float(line.split(">")[4].split("<")[0])
            #print offset
        if line.startswith("<TR><TD>Orientation:"):
            orientation=(line.split(">")[4].split("<")[0])
            #print orientation
        if line.startswith("<TR><TD>Alignment:"):
            motif=(line.split(">")[5].split("<")[0])
            #print motif
            mirna_seq=(line.split(">")[8].split("<")[0])
            #print mirna_seq
            #if orientation=="forward strand" and i==0:
             #   file_list_out.write("%s\n" %(file_out_base1.split(".")[0]))
              #  i=1
            if orientation=="reverse strand":
                seq=Seq(mirna_seq)
                length=len(seq)
                #print length
                pos_st=length+offset-7
                pos_end=length+offset
                CS=((pval-12)/12) + ((perc_seq-5)/100) + ((score-0.35)/0.175)
                file_out.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" %(file_out_base1.split(".")[0], pval, perc_seq, mirna_name, score, pos_st, pos_end, motif, CS ))
                if CS>=1 and i==0:
                    file_list_out.write("%s\n" %(file_out_base1.split(".")[0]))
                    i=1
        
        
        
        
    
    
    file_in.close()
    file_out.close()
    

    #print ("results stored into file '%s'. "% os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()        
    
