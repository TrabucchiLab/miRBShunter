import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
    
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    parser.add_option("-p", "--pvalue", action="store", dest="pvalue", default="0.001", type="float", help="set pvalue threshold. Default 0.001.")
    parser.add_option("-r", "--reads", action="store", dest="reads", default="10", type="int", help="set the minimal number of reads. Default is 10.")
    parser.add_option("-f", "--prefix", action="store", dest="prefix", default="test", type="string", help="prefix for output file. Default is test.")
    

    (options, args) = parser.parse_args()
    if len(args) != 1:
        parser.error("file bed 6 col (chr, st, end, pval, reads, strand) is required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    
   
    
    return options
    
    
    
def table(options):
    file_in_name1 = options.entity1
    
   
    file_out_base1 = os.path.splitext(os.path.basename(options.entity1))[0]
   
    file_out_name = os.path.join(options.outdir,'%s_pval%s_reads%s_peakname.bed' % ( options.prefix, options.pvalue, options.reads))
    
    
    
    
    file_in= file(file_in_name1, 'r')
   
    file_out = file(file_out_name, 'w')
    

    #parsing file .pk
    #list_array=[]
    i=0
    for line in file_in:
	#file_out.write("%s" %(line))
        
        pval=float(line.split("\t")[3])
        reads=float(line.split("\t")[4])
        if pval<= options.pvalue and reads>=options.reads:
            i=i+1
            file_out.write("%s\t%s\t%s\tpeak_%s\t%s\t%s" %(line.split("\t")[0], line.split("\t")[1], line.split("\t")[2], i, line.split("\t")[4], line.split("\t")[5]))
        
        
    
    file_in.close()
    file_out.close()
    

    #print ("results stored into file '%s'. "% os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()        
    
