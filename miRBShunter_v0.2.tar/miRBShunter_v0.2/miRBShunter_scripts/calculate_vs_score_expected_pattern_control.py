import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
from Bio.Seq import Seq

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
    
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    

    (options, args) = parser.parse_args()
    if len(args) != 3:
        parser.error("file energy_all, table_for_duplex and mirna sequences are required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    options.entity2 = args[1]
    options.entity3 = args[2]
   
    
    return options
    
    
    
def table(options):
    file_in_name1 = options.entity1
    file_in_name2 =  options.entity2
    file_in_name3 =  options.entity3
   
    file_out_base1 = os.path.splitext(os.path.basename(options.entity1))[0]
    #file_out_base2 = os.path.splitext(os.path.basename(options.entity2))[0]
    file_out_name = os.path.join(options.outdir,'results_table.txt')
    
    
    
    
    file_energy= file(file_in_name1, 'r')
    file_table = file(file_in_name2, 'r')
    file_mirna = file(file_in_name3, 'r')
    file_out = file(file_out_name, 'w')
    
    
    mirna_array=[]
    mirna_seq_array=[]
    #mirna_len_tab=[]
    for line in file_mirna:
        if line.startswith(">"):
            mirna_array.append(line.split(">")[1].split("_")[0].split("\n")[0])
        else:
            my_seq=Seq(line.split("\n")[0])
            mirna_seq_array.append(my_seq)#.reverse_complement())
        #mirna_len_tab.append(line.split("\t")[2].split("\n")[0])
    #print len(mirna_seq_array)
    
    
    name_table=[]
    mir_st_table=[]
    mir_end_table=[]
    mir_st_peak_table=[]
    mir_end_peak_table=[]
    word_table=[]
    mir_name_table=[]
    k=0
    for line in file_table:
        name=line.split("\t")[1]+"_"+line.split("\t")[13]+"_"+line.split("\t")[10]+"_"+line.split("\t")[9]+"_output"
        name_table.append(name)
        mir_st_table.append(float(line.split("\t")[15]))
        mir_end_table.append(float(line.split("\t")[16]))
        mir_st_peak_table.append(int(line.split("\t")[2]))
        mir_end_peak_table.append(int(line.split("\t")[3]))
        word_table.append(line.split("\t")[8])
        mir_name_table.append(line.split("\t")[13])
        """
        count_expected=0
        k=0
        for k in range(len(mirna_array)):
                        #print mir_name_table[j], mirna_array[k]
                        if line.split("\t")[13]==mirna_array[k]:
                            motif=line.split("\t")[8]
                            mirseq=mirna_seq_array[k]
                            subs=mirseq[int(float(line.split("\t")[15])):int(float(line.split("\t")[16]))]
                            subseq=subs.reverse_complement()
                            #print motif, subseq,mir_end_table[j], mir_st_table[j]
                            for u in range(len(subseq)):
                                if subseq[u]==motif[u] or (subseq[u]=="G" and motif[u]=="T") or (subseq[u]=="T" and motif[u]=="G"):
                                    count_expected=count_expected+1
        file_out.write("%s\t%s\t%s\n" %(line.split("\n")[0], count_expected, subseq))                           
        """
    #print name_table[0]
    
    name=[]
    energy=[]
    c_paired=[]
    c_n_paired=[]
    c_paired_motif_mir=[]
    c_paired_motif_target=[]
    c_paired_seed_mir=[]
    c_paired_seed_target=[]
    for line in file_energy:
        name.append(line.split("\t")[0])
        energy.append(float(line.split("\t")[1]))
        c_paired.append(int(line.split("\t")[2]))
        c_n_paired.append(int(line.split("\t")[3]))
        c_paired_motif_mir.append(int(line.split("\t")[4]))     
        c_paired_motif_target.append(int(line.split("\t")[5]))
        c_paired_seed_mir.append(int(line.split("\t")[6]))
        c_paired_seed_target.append(int(line.split("\t")[7].split("\n")[0]))
        
    min_energy=min(energy)
    #print min_energy
    
    i=0
    j=0
    k=0
    file_out.write("peakID\tmiRNA_name\tmotifID\tmotif\tstart_motif_miRNA\tend_motif_miRNA\tstart_motif_peak\tend_motif_peaks\tgenomic_coordinates_motif\tcount_paired_motif\tDS\n")
    #print len(name)
    for i in range(len(name)):
        
        if float(c_paired_motif_mir[i])-float(c_paired_motif_target[i])==0.0:
            count_expected=0
            
            for j in range(len(name_table)):
                if name_table[j]==name[i]:
                    
                    for k in range(len(mirna_array)):
                        #print "%s***%s***name" %(mir_name_table[j], mirna_array[k])
                        if mir_name_table[j]==mirna_array[k]:
                            
                            motif=word_table[j]
                            mirseq=mirna_seq_array[k]
                            subs=mirseq[int(mir_st_table[j]):int(mir_end_table[j])]
                            subseq=subs.reverse_complement()
                            #print motif, subseq,mir_end_table[j], mir_st_table[j]
                            for u in range(len(subseq)):
                                if subseq[u]==motif[u] or (subseq[u]=="G" and motif[u]=="T") or (subseq[u]=="T" and motif[u]=="G"):
                                    count_expected=count_expected+1
                                    start_motif_mirna=mir_st_table[j]
                                    end_motif_mirna=mir_end_table[j]
                                    start_motif_peak=mir_st_peak_table[j]
                                    end_motif_peak=mir_end_peak_table[j]
                                    motif_word=subseq
            #print count_expected, c_paired_motif_target[i]
            if count_expected==c_paired_motif_target[i] and count_expected>0:   
                      
                term1=energy[i]/min_energy
                term2=float(c_paired[i])/float((c_paired[i]+c_n_paired[i]))
                term3=float(c_paired_seed_mir[i])/7.0
                term5=float(c_paired_motif_mir[i])/7.0
                if float(c_paired_seed_mir[i])<=float(c_paired_seed_target[i]):
                    if float(c_paired_seed_target[i])==0.0:
                        term4=0
                        
                    else:
                        
                        term4=float(c_paired_seed_mir[i])/float(c_paired_seed_target[i])
                else:
                    
                    term4=float(c_paired_seed_target[i])/float(c_paired_seed_mir[i])
                
                vs=term1+term2+term3+term4+term5
                #print name[i], vs 
                file_out.write("peak_%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" %(name[i].split("_")[1], name[i].split("_")[2], name[i].split("_")[3], motif_word,  start_motif_mirna, end_motif_mirna, start_motif_peak , end_motif_peak , name[i].split("_")[4], c_paired_motif_target[i], vs))   
    
    file_energy.close()

    

    #print ("results stored into file '%s'. "% os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()        
    
