import os
import sys
from optparse import OptionParser
from math import sqrt
from operator import itemgetter
from scipy import stats
from scipy import special
import re

def main():
    opts=parse_cmd_line()
    
    table(opts) 
    
def ReverseComplement1(seq):
    seq_dict = {'A':'T', 'A':'U','T':'A','U':'A','G':'C','C':'G'}
    return "".join([seq_dict[base] for base in reversed(seq)])
  
    
def parse_cmd_line():
    #Parse the command line and return a parameters structure.

    usage = "usage: %prog [options] [structure]"
       
    parser = OptionParser(usage)
    parser.add_option("-o", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    #parser.add_option("-l", "--outdir", action="store", dest="outdir", default=".", type="string", help="directory for output file. Default is current directory.")
    

    (options, args) = parser.parse_args()
    if len(args) != 3:
        parser.error("peaks sequence fasta file, mirna file and table output homer are required.")

    if not os.path.isdir(options.outdir):
        parser.error("Not a valid directory: '%s'." % options.outdir)

    options.entity1 = args[0]
    options.entity2 = args[1]
    options.entity3 = args[2]
   
    
    return options
    
    
    
def table(options):

    file_in = file(options.entity1, 'r')
    file_mirna=file(options.entity2, 'r')
    file_tab=file(options.entity3, 'r')
    
    peak_name_homer=[]
    p_i=[]
    p_f=[]
    m_i=[]
    m_f=[]
    line_tab=[]
    mirna_name_homer=[]
    motif_name_homer=[]
    position_name_homer=[]
    for line in file_tab:
        if not line.startswith("gene ID"):
            motif_name_homer.append(line.split("\t")[0])
            peak_name_homer.append(line.split("\t")[1])
            position_name_homer.append(line.split("\t")[9])
            p_i.append(float(line.split("\t")[2]))
            p_f.append(float(line.split("\t")[3]))
            m_i.append(float(line.split("\t")[15]))
            m_f.append(float(line.split("\t")[16]))
            mirna_name_homer.append(line.split("\t")[13])
            line_tab.append(line.split("\n")[0])
    #print len(mirna_name_homer)
    ##print (mirna_name_homer)
    
    mirna_name_tab=[]
    mirna_seq_tab=[]
    #mirna_len_tab=[]
    for line in file_mirna:
        if line.startswith(">"):
            mirna_name_tab.append(line.split(">")[1].split("\n")[0])
        else:
            mirna_seq_tab.append(line.split("\n")[0])
        #mirna_len_tab.append(line.split("\t")[2].split("\n")[0])
    #print len(mirna_name_tab)
    ##print mirna_name_tab  
    
    i=0 
    for line in file_in:
        if line.startswith(">"):
            peak_name=line.split(">")[1].split("\n")[0]
            
            
        else:
            A=0
            for i in range(len(peak_name_homer)):
                if peak_name_homer[i]==peak_name:
                    
                    
                    name=line.split("\n")[0]
                    pi=int(p_i[i])
                    pf=int(p_f[i])
                    mi=int(m_i[i])
                    mf=int(m_f[i])
                    #print pi, pf, mi, mf
                    mirna_name=mirna_name_homer[i]
                    A=1
                    #file_out_name = os.path.join(options.outdir,'%s_let7.fa' % (name))
                    file_out_name = os.path.join(options.outdir,'%s_%s_motif%s_%s.fa' % (peak_name, mirna_name, motif_name_homer[i], position_name_homer[i]))
                    file_out_bed_name = os.path.join(options.outdir,'%s_%s_motif%s_%s.bed' % (peak_name, mirna_name, motif_name_homer[i], position_name_homer[i]))
                    file_out = file(file_out_name, 'w')
                    file_out_bed = file(file_out_bed_name, 'w')
                    #file_out.write("%s_let7\n" %(line.split("\n")[0]))
                    
                    """         
                    ##print mirna_name
                    for j in range(len(mirna_name_tab)):
                        ##print mirna_name_tab[j]
                        if mirna_name_tab[j]==mirna_name:
                            mirna_seq=mirna_seq_tab[j]
                            mirna_len=len(mirna_seq_tab[j])
                    seq=line.split("\n")[0]
                    pti=pf+mi-1
                    ptf=pi-(mirna_len-mf)-1
                    if ptf<=0:
                        ptf=1
                    #print pti, ptf
                    target_seq=seq[ptf:pti]
                    #print mirna_name, mirna_seq, peak_name,target_seq
                    #file_out.write(">let7\nUGAGGUAGUAGGUUGUAUAGUU\n%s\n%s\n" %(name,seq))
                    file_out.write(">%s\n%s\n>%s\n%s\n" %(mirna_name, mirna_seq, peak_name,target_seq))
                    file_out.close()
                    """
                    
                    ##print mirna_name
                    for j in range(len(mirna_name_tab)):
                        ##print mirna_name_tab[j]
                        if mirna_name_tab[j]==mirna_name:
                            mirna_seq=mirna_seq_tab[j]
                            mirna_len=len(mirna_seq_tab[j])
                    seq=line.split("\n")[0]
                    pf_bed=int(position_name_homer[i].split("-")[1].split("\t")[0])
                    pi_bed=int(position_name_homer[i].split(":")[1].split("-")[0])
                    if pf >=pi:
                        pti=pf+mi-1
                        ptf=pi-(mirna_len-mf)-2
                        #print pti, ptf
                        if ptf<0:
                            ptf=0
                        #if pti>mirna_len:
                         #   pti=mirna_len
                        target_seq=seq[ptf:pti]
                        pti_bed=pf_bed+mi-1
                        ptf_bed=pi_bed-(mirna_len-mf)-2
                        #print mirna_name, mirna_seq, peak_name,target_seq
                        name_output=peak_name+"_"+mirna_name+"_motif"+motif_name_homer[i]+"_"+position_name_homer[i]
                        #file_out.write(">let7\nUGAGGUAGUAGGUUGUAUAGUU\n%s\n%s\n" %(name,seq))
                        file_out_bed.write("%s\t%s\t%s\t%s\n" %(position_name_homer[i].split(":")[0], ptf_bed, pti_bed,name_output))
                        file_out.write(">%s\n%s\n>%s\n%s\n" %(mirna_name, mirna_seq, peak_name,target_seq))
                        file_out.close()
                        file_out_bed.close()
                    else:
                        pti=pi+mi-1
                        ptf=pf-(mirna_len-mf)-2
                        pti_bed=pi_bed+mi-1
                        ptf_bed=pf_bed-(mirna_len-mf)-2
                    #if ptf<=0:
                     #   ptf=1
                        #print pti, ptf
                        if ptf<0:
                            ptf=0
                        #if pti>mirna_len:
                         #   pti=mirna_len
                        target_seq=seq[ptf:pti]
                        #print mirna_name, mirna_seq, peak_name,target_seq
                        name_output=peak_name+"_"+mirna_name+"_motif"+motif_name_homer[i]+"_"+position_name_homer[i]
                        #file_out.write(">let7\nUGAGGUAGUAGGUUGUAUAGUU\n%s\n%s\n" %(name,seq))
                        file_out_bed.write("%s\t%s\t%s\t%s\n" %(position_name_homer[i].split(":")[0], ptf_bed, pti_bed,name_output))
                        file_out.write(">%s\n%s\n>%s\n%s\n" %(mirna_name, mirna_seq, peak_name,target_seq))
                        file_out.close()
                        file_out_bed.close()
                
            
   

    
    
    
    
    
            
            
    file_in.close()
    
    
    #print ("results stored into file '%s'. " % os.path.abspath(file_out_name) )
       


if __name__=='__main__':
    main()        
    
