#mac user that experience some problems can try export VERSIONER_PYTHON_PREFER_32_BIT=yes BEFORE THE SCRIPT!!!!

import wx
import os
import sys
import subprocess
import ctypes
# create simple class: Just a window. If you come from VB, a frame here is like VB window
#input=''
#probe=''

input_sad=''

class MainFrame(wx.Frame):

    
    
    def __init__(self):
        wx.Frame.__init__(self, None,wx.ID_ANY, title='miRBShunter', size=(900, 630))
        # self (which is now Text editor ) is now a Window with all attribute of a frame
        # Your widgets like buttons, text controls etc will be added here before showing the frame
        # as example I will add a panel
       
        
        self.background = wx.Panel(self)
        
        self.background.SetBackgroundColour("LightBlue")
        self.background.Refresh()
        
        #color = wx.SystemSettings.GetColour(wx.SYS_COLOUR_BACKGROUND)
        #self.SetBackgroundColour(color)
        #self.SetBackgroundColour(color)
        #self.SetBackgroundColour((134, 236, 789))
        #self.inputArea = wx.TextCtrl(self.background)
        
        img=wx.Image( "./miRBShunter_logo.png",  wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        #img = wx.ImageFromBitmap("./miRBShunter.png")
        #img = img.Scale(300, 200, wx.IMAGE_QUALITY_HIGH)
        self.bitmap1 = wx.StaticBitmap(self.background, -1, img, (10, 30))# size=(400, 150))
        
        ##img1=wx.Image( "./imgs_chipsad_gui/punto_esclam_rosso.jpeg",  wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        ##self.bitmap2 = wx.StaticBitmap(self.background, -1, img1, (500, 50))#, size=(400, 150))
        
        #wx.StaticText(self.background, -1, 'Microarray design options:', (500, 60) )
        
        #wx.StaticText(self.background, 1, 'Choose the signal to process:', (500, 100))
        ##sbs = wx.StaticBoxSizer(sb, orient=wx.VERTICAL)  
        #self.ChooseSignal=(wx.RadioButton(self.background, 1, label='Mvalue', pos=(500, 120), style=wx.RB_GROUP))
        #self.ChooseSignal=(wx.RadioButton(self.background, 1, label='Avalue', pos=(500, 140)))
        
        text=wx.StaticText(self.background, -1, 'Parameters:', (40, 260) )
        font = wx.Font(16, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
        text.SetFont(font)
        
        text=wx.StaticText(self.background, 2, 'Choose the organism.', (40, 310))
        font = wx.Font(12, wx.MODERN, wx.NORMAL, wx.NORMAL)
        text.SetFont(font)
        #sbs = wx.StaticBoxSizer(sb, orient=wx.VERTICAL)  
        self.ChooseDesign1=(wx.RadioButton(self.background, 2, label='Human', pos=(40, 330), style=wx.RB_GROUP))
        self.ChooseDesign2=(wx.RadioButton(self.background, 2, label='Mouse', pos=(40, 350)))
        
        text=wx.StaticText(self.background, -1, 'Set the minimun number of reads. ', (40, 390))
        font = wx.Font(12, wx.MODERN, wx.NORMAL, wx.NORMAL)
        text.SetFont(font)
        self.sc1 = wx.SpinCtrl(self.background, -1, '',  (370, 385), (60, -1))
        self.sc1.SetRange(3,200)
        self.sc1.SetValue(5)
        
        text=wx.StaticText(self.background, -1, 'Set the p-value threshold. ', (40, 450))
        font = wx.Font(12, wx.MODERN, wx.NORMAL, wx.NORMAL)
        text.SetFont(font)
        self.sc2 = wx.SpinCtrlDouble(self.background, -1, '',  (350, 445), (80, -1), inc=0.000001)
        self.sc2.SetRange(0.0,1.0)
        self.sc2.SetValue(0.001)
        
        basicLabel = wx.StaticText(self.background, 2, 'Write the prefix for output files:', (40, 510))
        self.basicText = wx.TextCtrl(self.background, -1, "", (40, 540), (380, -1))
        basicLabel.SetFont(font)
        
        
        
        ##img3=wx.Image( "./imgs_chipsad_gui/punto_interr_rosso.jpeg",  wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        ##self.bitmap4 = wx.StaticBitmap(self.background, -1, img3, (750, 10))#, size=(400, 150))
        self.MyHelpButton=wx.Button(self.background, label='Help', pos=(780, 20))
        self.MyHelpButton.Bind(wx.EVT_BUTTON, self.helpButton)
        self.MyHelpButton.SetBackgroundColour('Gold')

        
        
        
        
        
        ##img2=wx.Image( "./imgs_chipsad_gui/punto_esclam_rosso.jpeg",  wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        ##self.bitmap3 = wx.StaticBitmap(self.background, -1, img2, (20, 270))#, size=(400, 150))
        text=wx.StaticText(self.background, -1, 'Input files:', (460, 50) )
        font = wx.Font(16, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
        text.SetFont(font)
        
        self.MyInpButton=wx.Button(self.background, label='Load peaks bed file', pos=(460, 80))
        self.MyInpButton.Bind(wx.EVT_BUTTON, self.inputButton)
        self.transferArea1 = wx.TextCtrl(self.background, pos=(460,110), size=wx.Size(360, 40), style = wx.TE_READONLY |  wx.TE_BESTWRAP)
        

        self.MymiRNAButton=wx.Button(self.background, label='Load miRNAs sequences file' , pos=(460, 160))
        self.MymiRNAButton.Bind(wx.EVT_BUTTON, self.miRNAButton)
        self.transferArea2 = wx.TextCtrl(self.background, style = wx.TE_READONLY  | wx.TE_BESTWRAP, pos=(460,190), size=wx.Size(360, 40))
        
        
        self.MyProbeButton=wx.Button(self.background, label='Load background sequences file' , pos=(460, 240))
        self.MyProbeButton.Bind(wx.EVT_BUTTON, self.probeButton)
        self.transferArea6 = wx.TextCtrl(self.background, style = wx.TE_READONLY  | wx.TE_BESTWRAP, pos=(460,270), size=wx.Size(360, 40))
        
        
        self.MyhomerButton=wx.Button(self.background, label='Select the folder with genome fasta files' , pos=(460, 320))
        self.MyhomerButton.Bind(wx.EVT_BUTTON, self.homerButton)
        self.transferArea3 = wx.TextCtrl(self.background, style = wx.TE_READONLY  | wx.TE_BESTWRAP, pos=(460,350), size=wx.Size(360, 40))
        
        
        self.MyoutputButton=wx.Button(self.background, label='Select the output folder' , pos=(460, 400))
        self.MyoutputButton.Bind(wx.EVT_BUTTON, self.outputButton)
        self.transferArea4 = wx.TextCtrl(self.background, style = wx.TE_READONLY  | wx.TE_BESTWRAP, pos=(460,430), size=wx.Size(360, 40))
        
        
        self.MytempButton=wx.Button(self.background, label='Select the folder for temporary files' , pos=(460, 480))
        self.MytempButton.Bind(wx.EVT_BUTTON, self.tempButton)
        self.transferArea5 = wx.TextCtrl(self.background, style = wx.TE_READONLY  | wx.TE_BESTWRAP, pos=(460,510), size=wx.Size(360, 40))
        
        
        #wx.StaticText(self.background, -1, 'Set the computation step. Default 10: ', (440, 450))
        #self.sc3 = wx.SpinCtrl(self.background, -1, '',  (770, 440), (60, -1))
        #self.sc3.SetRange(1,100)
        #self.sc3.SetValue(10)
        
        self.MyComputeButton=wx.Button(self.background, label='Run' , pos=(770, 580))
        self.MyComputeButton.Bind(wx.EVT_BUTTON, self.Compute)
        self.MyComputeButton.SetBackgroundColour('LightGreen')
        
        #self.MyCloseButton=wx.Button(self.background, label='Close' , pos=(420, 500))
        #self.MyCloseButton.Bind(wx.EVT_BUTTON, self.Close)
        
        #self.timer = wx.Timer(self.background, 1)
        #self.gauge = wx.Gauge(self.background, -1,  size=(250, 25), pos=(325, 550))
        
        
        self.Show()
        
    
    
    
    def inputButton(self, event):
        dlg = wx.FileDialog(None, "Select a file", ".",
                           "default.txt",
                           "text file (*.txt)|*.txt|all files|*.*",
                           wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            wx.MessageBox("the choosen file is " + dlg.GetFilename() +
                         "\n\npath  " + dlg.GetPath())
            
            input=dlg.GetPath()
            self.transferArea1.SetValue(input)
            input_sad=self.transferArea1.SetValue(input)
            #self.inputvar.SetValue(input)
        # Ricordatevi sempre di distruggere la finestra!
        dlg.Destroy()
        return 1
    
    def miRNAButton(self, event):
        dlg = wx.FileDialog(None, "Select a file", ".",
                           "default.txt",
                           "text file (*.txt)|*.txt|all files|*.*",
                           wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            wx.MessageBox("the choosen file is " + dlg.GetFilename() +
                         "\npath  " + dlg.GetPath())
            
            probe=dlg.GetPath()
            self.transferArea2.SetValue(probe)
        # Ricordatevi sempre di distruggere la finestra!
        dlg.Destroy()
        return 1
    
    def probeButton(self, event):
        dlg = wx.FileDialog(None, "Select a file", ".",
                           "default.txt",
                           "text file (*.txt)|*.txt|all files|*.*",
                           wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            wx.MessageBox("the choosen file is " + dlg.GetFilename() +
                         "\npath  " + dlg.GetPath())
            
            probe=dlg.GetPath()
            self.transferArea6.SetValue(probe)
        # Ricordatevi sempre di distruggere la finestra!
        dlg.Destroy()
        return 1
    
    def outputButton(self, event):
        dialog = wx.DirDialog(None, "Choose a directory:",style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON)
        if dialog.ShowModal() == wx.ID_OK:
            
            wx.MessageBox("The selected folder is " + dialog.GetPath() )
            output=dialog.GetPath()
            self.transferArea4.SetValue(output)
        dialog.Destroy()

        return 1
    
    def homerButton(self, event):
        dialog = wx.DirDialog(None, "Choose a directory:",style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON)
        if dialog.ShowModal() == wx.ID_OK:
            
            wx.MessageBox("The selected folder is " + dialog.GetPath() )
            output=dialog.GetPath()
            self.transferArea3.SetValue(output)
        dialog.Destroy()

        return 1
    
    def tempButton(self, event):
        dialog = wx.DirDialog(None, "Choose a directory:",style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON)
        if dialog.ShowModal() == wx.ID_OK:
            
            wx.MessageBox("The selected folder is " + dialog.GetPath() )
            output=dialog.GetPath()
            self.transferArea5.SetValue(output)
        dialog.Destroy()

        return 1
    
    def helpButton(self, event):
        
        info=wx.MessageBox( 'Input files:\n-peaks bed file: a file with 6 columns (chr, st, end, pval, reads, strand).\n-miRNA sequences file: a file with the most expressed miRNA in fasta format\n-Background sequences file: fasta file with background sequences to use for motif de novo identification\n\nParameters:\n-Choose the organism: the genome can be mouse (mm10) or human (hg19)\n-Set the minimum number of reads: threshold for peaks to be considered in the analysis\n-Set the pvalue: threshold for peaks to be considered in the analysis\nWrite the prefix for output files: prefix to be used for output and temporary files.\n\nFor more information please see: https://github.com/TrabucchiLab/miRBShunter\nor contact: silvia.bottini@unice.fr', 'Help window:', wx.OK | wx.ICON_INFORMATION)
        info.ShowModal()
        return 1
    
    def Compute(self, vent):
        if self.ChooseDesign1.GetValue()==True:
            organism="hg19"
        if self.ChooseDesign2.GetValue()==True:
            organism="mm10"
        
        reads_min = str(self.sc1.GetValue())
        pval = str(self.sc2.GetValue())
        #organism = str(self.ChooseDesign.GetValue())
        prefix=str(self.basicText.GetValue())
        input=str(self.transferArea1.GetValue())
        mirna=str(self.transferArea2.GetValue())
        fastaBG=str(self.transferArea6.GetValue())
        output_directory=str(self.transferArea4.GetValue())
        homer_directory=str(self.transferArea3.GetValue())
        temp_directory=str(self.transferArea5.GetValue())
        if fastaBG=="":
            comand="python ./miRBShunter_script.py -o "+output_directory+"/ -t "+temp_directory+"/ -d "+homer_directory+"/ -p "+pval+" -r "+reads_min+" -g "+organism+" -f "+prefix+" "+input+" "+mirna
        else:
            comand="python ./miRBShunter_script.py -o "+output_directory+"/ -t "+temp_directory+"/ -d "+homer_directory+"/ -p "+pval+" -r "+reads_min+" -g "+organism+" -f "+prefix+" -b "+fastaBG+" "+input+" "+mirna
        #comand="python ./chipSAD.py "+input_sad+" "+probe_sad+" "+ttestsad+" -o "+output_sad+ " -w "+width+" -s "+step+" -m "+min
        #+"-d "+design+" -k "+signal
        #print comand
        if ctypes.sizeof(ctypes.c_voidp)==8:
            ret2=os.system(comand)
            if ret2==0:
                print "Done!"
        
    def Close(self, event):

        dial = wx.MessageDialog(None, 'Are you sure you want to quit?', 'Question',
            wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
            
        ret = dial.ShowModal()
        
        if ret == wx.ID_YES:
            self.Destroy()
        else:
            event.Skip()

 
   
   
#define ad loop your application
MyApp= wx.App(redirect=False)
frame= MainFrame()
MyApp.MainLoop()
       
